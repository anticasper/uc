(function () {
  const UF_BY_STATE = {
    Acre: "AC",
    Alagoas: "AL",
    Amapa: "AP",
    Amazonas: "AM",
    Bahia: "BA",
    Ceara: "CE",
    "Distrito Federal": "DF",
    "Espirito Santo": "ES",
    Goias: "GO",
    Maranhao: "MA",
    "Mato Grosso": "MT",
    "Mato Grosso do Sul": "MS",
    "Minas Gerais": "MG",
    Para: "PA",
    Paraiba: "PB",
    Parana: "PR",
    Pernambuco: "PE",
    Piaui: "PI",
    "Rio de Janeiro": "RJ",
    "Rio Grande do Norte": "RN",
    "Rio Grande do Sul": "RS",
    Rondonia: "RO",
    Roraima: "RR",
    "Santa Catarina": "SC",
    "Sao Paulo": "SP",
    Sergipe: "SE",
    Tocantins: "TO",
  };

  function normalize(text) {
    return String(text || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .toLowerCase();
  }

  function decodeHtml(value) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = String(value ?? "");
    return textarea.value;
  }

  function firstValue(...values) {
    const value = values.find((item) => item !== undefined && item !== null && String(item).trim() !== "");
    return value === undefined ? "" : decodeHtml(value);
  }

  function getActivities(item) {
    if (Array.isArray(item?.atividades)) {
      return item.atividades;
    }

    if (Array.isArray(item?.activities)) {
      return item.activities;
    }

    return [];
  }

  function getUfLabel(stateName) {
    const key = Object.keys(UF_BY_STATE).find((name) => normalize(name) === normalize(stateName));
    return key ? UF_BY_STATE[key] : String(stateName || "").slice(0, 2).toUpperCase();
  }

  function uniqueSorted(items, key) {
    return [...new Set(items.map((item) => item[key]).filter(Boolean))]
      .sort((a, b) => a.localeCompare(b, "pt-BR"));
  }

  function createCheckbox(label, value, checked, onChange) {
    const row = document.createElement("label");
    row.className = "uc-checkbox";

    const input = document.createElement("input");
    input.type = "checkbox";
    input.value = value;
    input.checked = checked;
    input.addEventListener("change", () => onChange(value, input.checked));

    const text = document.createElement("span");
    text.textContent = label;

    row.append(input, text);
    return row;
  }

  function getSearchSource(item) {
    return [
      item.name,
      item.city,
      item.state,
      item.biome,
      item.activity,
      item.endereco,
      item.cep,
    ].join(" ");
  }

  function activitySummary(activity) {
    return [
      firstValue(activity.data, activity.date) ? `Data: ${firstValue(activity.data, activity.date)}` : "",
      firstValue(activity.horario, activity.time) ? `Horario: ${firstValue(activity.horario, activity.time)}` : "",
      firstValue(activity.publico, activity.audience) ? `Publico: ${firstValue(activity.publico, activity.audience)}` : "",
      firstValue(activity.dificuldade, activity.difficulty) ? `Dificuldade: ${firstValue(activity.dificuldade, activity.difficulty)}` : "",
    ].filter(Boolean);
  }

  function normalizeItem(item) {
    const atividades = getActivities(item);

    return {
      ...item,
      id: item.id ?? item.source_id,
      name: firstValue(item.name, item.title, "UC sem nome"),
      state: firstValue(item.state, item.estado, item.uf),
      uf: firstValue(item.uf),
      city: firstValue(item.city, item.municipio),
      biome: firstValue(item.biome, item.bioma),
      activity: firstValue(item.activity, atividades[0]?.title, atividades[0]?.titulo, atividades[0]?.tipo),
      description: firstValue(item.description, item.excerpt, item.content, item.breve_descricao),
      endereco: firstValue(item.endereco),
      cep: firstValue(item.cep),
      url: firstValue(item.url, item.link),
      slug: firstValue(item.slug, item.uc_slug),
      image_url: firstValue(item.image_url, item.thumbnail),
      atividades,
    };
  }

  function initList(root) {
    const state = {
      items: [],
      search: "",
      biomes: new Set(),
      states: new Set(),
    };

    const searchInput = root.querySelector("[data-list-search]");
    const biomeOptions = root.querySelector("[data-biome-options]");
    const stateOptions = root.querySelector("[data-state-options]");
    const resultsCount = root.querySelector("[data-uc-results-count]");
    const cardsGrid = root.querySelector("[data-uc-cards-grid]");
    const emptyState = root.querySelector("[data-uc-empty]");
    const cardTemplate = root.querySelector("[data-uc-card-template]");
    const modal = root.querySelector("[data-activity-modal]");
    const modalTitle = root.querySelector("[data-activity-modal-title]");
    const modalMeta = root.querySelector("[data-activity-modal-meta]");
    const modalBody = root.querySelector("[data-activity-modal-body]");

    function filteredItems() {
      const search = normalize(state.search);

      return state.items.filter((item) => {
        return (
          (!search || normalize(getSearchSource(item)).includes(search)) &&
          (!state.biomes.size || state.biomes.has(item.biome)) &&
          (!state.states.size || state.states.has(item.state))
        );
      });
    }

    function renderFilters() {
      biomeOptions.innerHTML = "";
      stateOptions.innerHTML = "";

      uniqueSorted(state.items, "biome").forEach((biome) => {
        biomeOptions.appendChild(createCheckbox(biome, biome, state.biomes.has(biome), (value, checked) => {
          checked ? state.biomes.add(value) : state.biomes.delete(value);
          renderCards();
        }));
      });

      uniqueSorted(state.items, "state").forEach((stateName) => {
        const label = `${stateName} (${getUfLabel(stateName)})`;
        stateOptions.appendChild(createCheckbox(label, stateName, state.states.has(stateName), (value, checked) => {
          checked ? state.states.add(value) : state.states.delete(value);
          renderCards();
        }));
      });
    }

    function createCard(item) {
      const card = cardTemplate.content.firstElementChild.cloneNode(true);
      const meta = [item.city, item.state, item.biome].filter(Boolean).join(" | ");

      card.querySelector("[data-uc-name]").textContent = item.name || "UC sem nome";
      card.querySelector("[data-uc-meta]").textContent = meta;
      card.querySelector("[data-open-activities]").addEventListener("click", () => openActivities(item));

      return card;
    }

    function renderCards() {
      const items = filteredItems();
      cardsGrid.innerHTML = "";
      resultsCount.textContent = String(items.length);
      emptyState.hidden = items.length > 0;

      const fragment = document.createDocumentFragment();
      items.forEach((item) => fragment.appendChild(createCard(item)));
      cardsGrid.appendChild(fragment);
    }

    function openActivities(item) {
      const activities = getActivities(item);
      modalTitle.textContent = item.name || "Atividades";
      modalMeta.textContent = [item.city, item.state, item.biome].filter(Boolean).join(" | ");
      modalBody.innerHTML = "";

      if (!activities.length) {
        const fallback = document.createElement("p");
        fallback.className = "activity-modal__empty";
        fallback.textContent = item.description || "Nenhuma atividade cadastrada para esta UC.";
        modalBody.appendChild(fallback);
      } else {
        activities.forEach((activity, index) => {
          const article = document.createElement("article");
          article.className = "activity-item";

          const title = document.createElement("h3");
          title.textContent = firstValue(activity.titulo, activity.title, activity.tipo, `Atividade ${index + 1}`);

          const description = document.createElement("p");
          description.textContent = firstValue(activity.descricao, activity.description, activity.excerpt, activity.content, activity.texto_completo, "Sem descricao.");

          const details = document.createElement("ul");
          activitySummary(activity).forEach((line) => {
            const detail = document.createElement("li");
            detail.textContent = line;
            details.appendChild(detail);
          });

          article.append(title);
          if (details.childElementCount) {
            article.appendChild(details);
          }
          article.appendChild(description);
          modalBody.appendChild(article);
        });
      }

      modal.hidden = false;
      document.documentElement.classList.add("uc-modal-open");
    }

    function closeActivities() {
      modal.hidden = true;
      document.documentElement.classList.remove("uc-modal-open");
    }

    root.querySelectorAll("[data-close-activity-modal]").forEach((button) => {
      button.addEventListener("click", closeActivities);
    });

    searchInput.addEventListener("input", () => {
      state.search = searchInput.value;
      renderCards();
    });

    async function loadItems() {
      const urls = [
        window.UCListConfig?.dataUrl,
        window.UCListConfig?.fallbackDataUrl,
        "./map-data.json",
      ].filter(Boolean);
      let payload = null;
      let lastError = null;

      for (const url of [...new Set(urls)]) {
        try {
          const response = await fetch(url, { cache: "no-store" });

          if (!response.ok) {
            throw new Error(`Falha ao carregar ${url} (${response.status})`);
          }

          payload = await response.json();
          break;
        } catch (error) {
          lastError = error;
        }
      }

      if (!payload) {
        throw lastError || new Error("Nenhuma fonte de dados configurada.");
      }

      state.items = (payload.items || [])
        .filter(Boolean)
        .map(normalizeItem)
        .filter((item) => item && item.name)
        .sort((a, b) => a.name.localeCompare(b.name, "pt-BR"));

      renderFilters();
      renderCards();
    }

    loadItems().catch((error) => {
      console.error(error);
      cardsGrid.innerHTML = "";
      resultsCount.textContent = "0";
      emptyState.hidden = false;
      emptyState.textContent = "Nao foi possivel carregar a lista de UCs.";
    });
  }

  document.querySelectorAll(".uc-list-root").forEach(initList);
})();
