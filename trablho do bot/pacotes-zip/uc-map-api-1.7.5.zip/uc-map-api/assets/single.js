(function () {
  const config = window.UCSingleConfig || {};

  if (!config.apiUrl || !document.body.classList.contains("single-uc")) {
    return;
  }

  function decodeHtml(value) {
    const textarea = document.createElement("textarea");
    textarea.innerHTML = String(value ?? "");
    return textarea.value;
  }

  function firstValue(...values) {
    const value = values.find((item) => item !== undefined && item !== null && String(item).trim() !== "");
    return value === undefined ? "" : decodeHtml(value);
  }

  function textOf(node) {
    return String(node?.textContent || "").replace(/\s+/g, " ").trim();
  }

  function normalizeText(value) {
    return String(value || "")
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .replace(/\s+/g, " ")
      .trim()
      .toLowerCase();
  }

  function matchesText(node, value) {
    return normalizeText(textOf(node)) === normalizeText(value);
  }

  function setText(node, value) {
    if (node && value) {
      node.textContent = value;
    }
  }

  function parseCoordinate(value) {
    const normalized = String(value ?? "").trim().replace(",", ".");
    const parsed = Number(normalized);
    return Number.isFinite(parsed) ? parsed : null;
  }

  function getCoordinates(item) {
    const lat = parseCoordinate(item.lat);
    const lng = parseCoordinate(item.lng);

    if (lat === null || lng === null) {
      return null;
    }

    return { lat, lng };
  }

  function extractFirstUrl(value) {
    return firstValue(value).match(/https?:\/\/[^\s<>"']+/i)?.[0] || "";
  }

  function cleanAddress(value) {
    return firstValue(value)
      .replace(/https?:\/\/[^\s<>"']+/gi, "")
      .replace(/(?:localiza[cç][aã]o no google maps|google maps|endere[cç]o)\s*:?/gi, "")
      .replace(/\s+/g, " ")
      .trim();
  }

  function getActivities(item) {
    return Array.isArray(item?.atividades) ? item.atividades : [];
  }

  function normalizePhone(...values) {
    const digits = firstValue(...values).replace(/\D+/g, "");

    if (!digits) {
      return "";
    }

    if (digits.startsWith("55")) {
      return digits;
    }

    return digits.length >= 10 && digits.length <= 11 ? `55${digits}` : digits;
  }

  function buildWhatsAppUrl(activity, item) {
    const phone = normalizePhone(
      activity.whatsapp,
      activity.telefone,
      activity.phone,
      activity.meta?._atividade_whatsapp,
      item.whatsapp,
      item.telefone,
      item.phone,
      item.meta?._uc_whatsapp
    );

    if (!phone) {
      return "";
    }

    const activityTitle = firstValue(activity.titulo, activity.title, activity.tipo);
    const ucTitle = firstValue(item.name, item.title);
    const text = [
      "Olá! Tenho interesse em participar da atividade.",
      activityTitle ? `Atividade: ${activityTitle}` : "",
      ucTitle ? `UC: ${ucTitle}` : "",
    ].filter(Boolean).join("\n");

    return `https://wa.me/${phone}?text=${encodeURIComponent(text)}`;
  }

  function getMapUrl(item) {
    const coordinates = getCoordinates(item);
    const directUrl = firstValue(item.link_do_endereco, extractFirstUrl(item.endereco));
    const address = cleanAddress(item.endereco);

    if (directUrl) {
      return directUrl;
    }

    if (coordinates) {
      return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${coordinates.lat},${coordinates.lng}`)}`;
    }

    if (address) {
      return `https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(address)}`;
    }

    return "";
  }

  function getMapEmbedQuery(item) {
    const coordinates = getCoordinates(item);

    if (coordinates) {
      return `${coordinates.lat},${coordinates.lng}`;
    }

    return cleanAddress(item.endereco) || firstValue(item.city, item.state, item.uf, item.name);
  }

  function allElements(selector) {
    return Array.from(document.querySelectorAll(selector));
  }

  function findByText(selector, value) {
    return allElements(selector).find((node) => matchesText(node, value));
  }

  function findAllByText(selector, value) {
    return allElements(selector).filter((node) => matchesText(node, value));
  }

  function findTextWidgetAfter(labelNode) {
    let cursor = labelNode?.closest(".elementor-element");

    while (cursor) {
      cursor = cursor.nextElementSibling;

      if (!cursor) {
        return null;
      }

      const text = cursor.querySelector(".elementor-widget-text-editor p, .elementor-widget-text-editor");
      if (text) {
        return text;
      }
    }

    return null;
  }

  function setValueAfterLabel(root, labels, value) {
    if (!root) {
      return;
    }

    const labelList = Array.isArray(labels) ? labels : [labels];
    const labelNode = Array.from(root.querySelectorAll(".elementor-heading-title, h1, h2, h3, span"))
      .find((node) => labelList.some((label) => matchesText(node, label)));

    const valueNode = findTextWidgetAfter(labelNode);
    if (valueNode) {
      valueNode.textContent = value || "";
      valueNode.hidden = !value;
    }
  }

  function activitySummary(activity) {
    return [
      firstValue(activity.data, activity.date),
      firstValue(activity.horario, activity.time),
    ].filter(Boolean).join(" - ");
  }

  function setActivityButton(button, url) {
    const widget = button?.closest(".elementor-widget-button") || button;

    if (!button) {
      return;
    }

    if (!url) {
      button.removeAttribute("href");
      button.hidden = true;
      button.setAttribute("aria-hidden", "true");
      if (widget) {
        widget.hidden = true;
        widget.setAttribute("aria-hidden", "true");
        widget.style.display = "none";
      }
      return;
    }

    button.href = url;
    button.target = "_blank";
    button.rel = "noopener";
    button.hidden = false;
    button.removeAttribute("aria-hidden");
    if (widget) {
      widget.hidden = false;
      widget.removeAttribute("aria-hidden");
      widget.style.display = "";
    }
  }

  function setSlideVisible(slide, isVisible) {
    if (!slide) {
      return;
    }

    slide.hidden = !isVisible;
    slide.classList.toggle("uc-activity-slide-hidden", !isVisible);
    slide.setAttribute("aria-hidden", isVisible ? "false" : "true");
    slide.style.display = isVisible ? "" : "none";
  }

  function trimActivitySwiperSlides(swiperElement, activityCount) {
    const slides = Array.from(swiperElement.querySelectorAll(".swiper-slide"));
    const seenIndexes = new Set();
    let sequentialIndex = 0;

    slides.forEach((slide) => {
      const rawIndex = slide.getAttribute("data-swiper-slide-index");
      const index = rawIndex === null ? sequentialIndex++ : Number(rawIndex);
      const hasValidIndex = Number.isInteger(index) && index >= 0 && index < activityCount;
      const wasSeen = seenIndexes.has(index);

      if (!hasValidIndex || wasSeen) {
        slide.remove();
        return;
      }

      seenIndexes.add(index);
      setSlideVisible(slide, true);
    });
  }

  function updateActivitySwipers(slides, activityCount) {
    const swipers = [...new Set([...slides].map((slide) => slide?.closest(".swiper")).filter(Boolean))];

    swipers.forEach((swiperElement) => {
      const swiper = swiperElement.swiper;

      if (!swiper) {
        return;
      }

      try {
        if (swiper.params) {
          swiper.params.loop = false;
        }
        if (typeof swiper.loopDestroy === "function") {
          swiper.loopDestroy();
        }
        trimActivitySwiperSlides(swiperElement, activityCount);
        if (typeof swiper.updateSlides === "function") {
          swiper.updateSlides();
        }
        if (typeof swiper.update === "function") {
          swiper.update();
        }
      } catch (error) {
        console.warn("Nao foi possivel atualizar o slider de atividades.", error);
      }
    });
  }

  function hydrateActivityCards(activities, item) {
    const titleNodes = findAllByText(".elementor-heading-title", "Nome da atividade");
    const usedSlides = new Set();

    titleNodes.forEach((titleNode, index) => {
      const activity = activities[index];
      const slide = titleNode.closest(".swiper-slide") || titleNode.closest(".e-con") || titleNode.closest(".elementor-element");

      if (slide) {
        usedSlides.add(slide);
      }

      if (!activity) {
        setText(titleNode, "");

        if (slide) {
          Array.from(slide.querySelectorAll(".elementor-widget-text-editor p")).forEach((node) => {
            node.textContent = "";
          });
          const button = slide.querySelector("a.elementor-button, a");
          setActivityButton(button, "");
          setSlideVisible(slide, false);
        }
        return;
      }

      const title = firstValue(activity.titulo, activity.title, activity.tipo);
      const description = firstValue(activity.descricao, activity.description, activity.excerpt, activity.content);
      const difficulty = firstValue(activity.dificuldade, activity.difficulty);
      const audience = firstValue(activity.publico, activity.audience);
      const url = buildWhatsAppUrl(activity, item);

      setText(titleNode, title);

      if (slide) {
        setSlideVisible(slide, true);
        setValueAfterLabel(slide, ["Data e Horario", "Data e Hor\u00e1rio", "Data e HorÃ¡rio"], activitySummary(activity));
        setValueAfterLabel(slide, ["Descricao curta", "Descri\u00e7\u00e3o curta", "DescriÃ§Ã£o curta", "Descricao", "Descri\u00e7\u00e3o"], description);
        setValueAfterLabel(slide, "Dificuldade", difficulty);
        setValueAfterLabel(slide, ["Publico", "P\u00fablico", "PÃºblico"], audience);

        const button = Array.from(slide.querySelectorAll("a.elementor-button, a"))
          .find((link) => /inscreva-se/i.test(textOf(link)) || link.getAttribute("href") === "#");

        setActivityButton(button, url);
      }
    });

    updateActivitySwipers(usedSlides, activities.length);
  }

  function hydrateInfoCards(item, activities) {
    const location = [firstValue(item.city), firstValue(item.state, item.uf)].filter(Boolean).join(" - ");
    const firstActivity = activities[0] || {};
    const infoByLabel = {
      "Localização": location,
      "Horário": activitySummary(firstActivity),
      "Gratuito/Pago": "Gratuito",
      "Atividades": activities.length ? `${activities.length} ${activities.length === 1 ? "atividade cadastrada" : "atividades cadastradas"}` : "",
      "Estacionamento": firstValue(item.estacionamento_text, item.estacionamento, item.meta?._uc_estacionamento_status),
      "Acessibilidade": firstValue(item.acessibilidade_text, item.acessibilidade, item.meta?._uc_acessibilidade_status),
    };

    Object.entries(infoByLabel).forEach(([label, value]) => {
      if (!value) {
        return;
      }

      const titleNode = findByText(".elementor-icon-box-title span, .elementor-icon-box-title", label);
      const box = titleNode?.closest(".elementor-icon-box-content");
      const description = box?.querySelector(".elementor-icon-box-description");
      setText(description, value);
    });
  }

  function hydrateRoute(item) {
    const mapUrl = getMapUrl(item);
    const routeTitle = findByText(".elementor-heading-title", "Como chegar");
    let section = routeTitle?.closest(".e-con");

    while (section && !section.querySelector("iframe")) {
      section = section.parentElement?.closest(".e-con");
    }

    if (!section) {
      section = routeTitle?.closest(".e-con");
    }

    if (routeTitle) {
      let cursor = routeTitle.closest(".elementor-element")?.previousElementSibling;
      while (cursor) {
        const text = cursor.querySelector(".elementor-widget-text-editor p, .elementor-widget-text-editor");
        if (text) {
          setText(text, "Sobre o local");
          break;
        }
        cursor = cursor.previousElementSibling;
      }
    }

    if (section && mapUrl) {
      const button = Array.from(section.querySelectorAll("a.elementor-button, a"))
        .find((link) => /abrir no google maps/i.test(textOf(link)));
      if (button) {
        button.href = mapUrl;
        button.target = "_blank";
        button.rel = "noopener";
      }

      const iframe = section.querySelector("iframe");
      if (iframe) {
        const query = getMapEmbedQuery(item);
        iframe.src = `https://maps.google.com/maps?q=${encodeURIComponent(query)}&t=m&z=10&output=embed&iwloc=near`;
        iframe.title = query;
        iframe.setAttribute("aria-label", query);
      }
    }
  }

  function findHeroSubtitle(item) {
    const title = firstValue(item.name, item.title);
    const titleNode = allElements(".elementor-heading-title, h1, h2")
      .find((node) => title && matchesText(node, title));

    if (!titleNode) {
      return findByText(".elementor-widget-text-editor p", "Uma experiência de conexão com a natureza em uma das áreas protegidas mais incríveis do país.")
        || findByText(".elementor-widget-text-editor p", "Uma experiÃªncia de conexÃ£o com a natureza em uma das Ã¡reas protegidas mais incrÃ­veis do paÃ­s.");
    }

    let section = titleNode.closest(".e-con");

    while (section && !section.querySelector(".elementor-widget-text-editor p, .elementor-widget-text-editor")) {
      section = section.parentElement?.closest(".e-con");
    }

    if (!section) {
      return null;
    }

    const titleWidget = titleNode.closest(".elementor-element");
    let cursor = titleWidget;

    while (cursor && cursor.parentElement === titleWidget?.parentElement) {
      cursor = cursor.nextElementSibling;

      const text = cursor?.querySelector(".elementor-widget-text-editor p, .elementor-widget-text-editor");
      if (text) {
        return text;
      }
    }

    return section.querySelector(".elementor-widget-text-editor p, .elementor-widget-text-editor");
  }

  function hydrateHero(item) {
    const subtitle = findHeroSubtitle(item);
    const description = firstValue(
      item.breve_descricao,
      item.meta?._uc_breve_descricao,
      item.description,
      item.excerpt,
      item.content
    );

    if (subtitle) {
      subtitle.textContent = description;
      subtitle.hidden = !description;
    }
  }

  async function hydrate() {
    try {
      const response = await fetch(config.apiUrl, { cache: "no-store" });

      if (!response.ok) {
        throw new Error(`Falha ao carregar UC (${response.status})`);
      }

      const item = await response.json();

      if (!item || !item.id) {
        throw new Error("UC nao encontrada na API.");
      }

      const activities = getActivities(item);
      const applyHydration = () => {
        hydrateHero(item);
        hydrateActivityCards(activities, item);
        hydrateInfoCards(item, activities);
        hydrateRoute(item);
        document.documentElement.classList.add("uc-single-data-ready");
      };

      applyHydration();
      window.setTimeout(applyHydration, 800);
      window.setTimeout(applyHydration, 1800);
      window.setTimeout(applyHydration, 3500);
    } catch (error) {
      console.error(error);
    }
  }

  hydrate();
})();
